#include "Player.h"

void Player::update() {
	cam.update();
}
